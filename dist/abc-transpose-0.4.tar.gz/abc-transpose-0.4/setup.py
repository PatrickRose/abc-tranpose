from distutils.core import setup
setup(name='abc-transpose',
      version='0.4',
      description='abc transposer',
      author='Patrick Rose',
      author_email='pjr0911025@googlemail.com',
      url='https://github.com/PatrickRose/abc-tranpose',
      py_modules=['abc-transpose'],
      package_dir={'': 'src'},
      )

